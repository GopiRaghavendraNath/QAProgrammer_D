package com.manoj.selenium.supportcode;

import org.openqa.selenium.WebDriver;

public interface SeleniumDriverObj {
	public WebDriver getDriver(String browerName);
}
