package com.manoj.cucumber.supportcode;

public class Login {

  private String userId;
  private String pasword;

  public String getUserId() {
    return userId;
  }

  public void setUserId(final String userId) {
    this.userId = userId;
  }

  public String getPasword() {
    return pasword;
  }

  public void setPasword(final String pasword) {
    this.pasword = pasword;
  }

}
